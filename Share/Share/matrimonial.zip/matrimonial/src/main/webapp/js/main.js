document.addEventListener("DOMContentLoaded", function(event) {
  document.getElementById("login-btn").addEventListener("click", function(eventM) {
    eventM.preventDefault();
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        if (this.responseText == "false") {
          alert("Invalid username and password.");
        } else if (this.responseText == "true") {
          alert("Login successfully.");
        }
      }
    };
    xhttp.open("POST", "AddUserController", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    var usernameL = document.getElementById("your_name").value;
    var passwordL = document.getElementById("your_pass").value;
    if (usernameL == "") {
      alert("Please enter the username.");
      return false;
    }
    if (passwordL == "") {
      alert("Please enter the password.");
      return false;
    }
    xhttp.send("USER_ID=" + encodeURIComponent(usernameL) + "&USER_PASSWORD=" + encodeURIComponent(passwordL));
  });

  document.getElementById("sign-up-btn").addEventListener(
          "click",
          function(eventM) {
            eventM.preventDefault();
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                if (this.responseText == "false") {
                  alert("Email already registered.");
                } else if (this.responseText == "true") {
                  alert("User successfully registered.");
                }
              }
            };
            xhttp.open("POST", "AddUserController", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            var usernameL = document.getElementById("user-email").value;
            if (usernameL == "") {
              alert("Please enter the email.");
              return false;
            }

            var nameL = document.getElementById("user-name").value;
            if (nameL == "") {
              alert("Please enter the name.");
              return false;
            }
            var passwordL = document.getElementById("user-password").value;
            var confirmPasswordL = document.getElementById("user-confirm-password").value;
            if (passwordL == "") {
              alert("Please enter the password.");
              return false;
            }
            xhttp.send("USER_EMAIL=" + encodeURIComponent(usernameL) + "&USER_PASSWORD=" + encodeURIComponent(passwordL) + "&USER_NAME=" +
                    encodeURIComponent(nameL));
          });
  document.querySelector(".signup-image-link").addEventListener("click", function() {
    document.getElementById("sign-in-section").style.display = "none";
    document.getElementById("sign-up-section").style.display = "block";
  });

  document.querySelector(".signin-image-link").addEventListener("click", function() {
    document.getElementById("sign-in-section").style.display = "block";
    document.getElementById("sign-up-section").style.display = "none";
  });
});

var ajaxLoaderCountInt = 0;
/**
 * Shows the ajax loader.
 */
function showAjaxLoader() {
  ajaxLoaderCountInt++;
  document.getElementsByTagName("body")[0].classList.add("ajax-loader");
}

/**
 * Hide the ajax loader.
 */
function hideAjaxLoader() {
  ajaxLoaderCountInt--;
  if (ajaxLoaderCountInt == 0) {
    document.getElementsByTagName("body")[0].classList.remove("ajax-loader");
  }
}