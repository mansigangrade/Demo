package com.matrimonial.common.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ResourceBundle;

/**
 * A class is used to create a database connection.
 */
public class ConnectionManager {
  ResourceBundle dbResourceBundle = ResourceBundle.getBundle("com.matrimonial.common.resources.DBDetails");

  private static ConnectionManager connectionManager;
  static {
    connectionManager = new ConnectionManager();
  }

  /**
   * Gets the instance of connection manager class.
   * 
   * @return the object of ConnectionManager
   */
  public static ConnectionManager getInstance() {
    return connectionManager;
  }

  /**
   * Gets the database connection.
   * 
   * @return the connection object.
   * 
   */
  public Connection getConnection() {
    Connection connectionL = null;
    try {
      // Class.forName(dbResourceBundle.getString("Database.driver"));
      // String dnsNameL = dbResourceBundle.getString("Database.driver") + dbResourceBundle.getString("Database.Port") + "//"
      // + dbResourceBundle.getString("Database.Name");
      // connectionL = DriverManager.getConnection(dnsNameL, dbResourceBundle.getString("Database.Username"),
      // dbResourceBundle.getString("Database.Password"));
      Class.forName("com.mysql.jdbc.Driver");
      connectionL = DriverManager.getConnection("jdbc:mysql://localhost:3306/MATRIMONIALDB", "root", "admina");

    } catch (Exception exception) {
      exception.printStackTrace();
      System.out.println("Error is coming while creating connection.");
    }
    return connectionL;
  }
}
