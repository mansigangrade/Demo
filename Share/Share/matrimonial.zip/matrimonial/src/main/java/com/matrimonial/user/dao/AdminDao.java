package com.matrimonial.user.dao;

import com.matrimonial.common.dao.ConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * 
 * @author Ganesh Patel
 *
 */
public class AdminDao {
  /**
   * Checks if is valid user or not.
   * 
   * @param userId the user ID
   * @param password the password of user.
   * @return <code>true</code>, if user is valid, otherwise <code>false</code>.
   */
  public boolean isValidUser(String userId, String password) {
    boolean isValidUserL = false;
    Connection connectionL = null;
    ResultSet resultSetL = null;
    try {
      connectionL = ConnectionManager.getInstance().getConnection();
      String queryL = "SELECT * FROM USER_INFO_TBL WHERE EMAIL='" + userId + "' AND PASSWORD='" + password + "';";
      PreparedStatement preparedStatementL = connectionL.prepareStatement(queryL);
      resultSetL = preparedStatementL.executeQuery();
      if (resultSetL.next()) {
        isValidUserL = true;
      }
      resultSetL.close();
      preparedStatementL.close();
      connectionL.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    }
    return isValidUserL;
  }

  /**
   * Checks if is unique email or not.
   * 
   * @param email the email ID of user
   * @return <code>true</code>, if email is unique, otherwise <code>false</code>.
   */
  public boolean isUniqueEmail(String email) {
    boolean isValidUserL = true;
    Connection connectionL = null;
    ResultSet resultSetL = null;
    try {
      connectionL = ConnectionManager.getInstance().getConnection();
      String queryL = "SELECT * FROM USER_INFO_TBL WHERE EMAIL='" + email + "';";
      PreparedStatement preparedStatementL = connectionL.prepareStatement(queryL);
      resultSetL = preparedStatementL.executeQuery();
      if (resultSetL.next()) {
        isValidUserL = false;
      }
      resultSetL.close();
      preparedStatementL.close();
      connectionL.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    }
    return isValidUserL;
  }

  /**
   * INserts the user.
   * 
   * @param email the email
   * @param name the name
   * @param password the password
   */
  public void insertUser(String email, String name, String password) {
    boolean isValidUserL = true;
    Connection connectionL = null;
    ResultSet resultSetL = null;
    try {
      connectionL = ConnectionManager.getInstance().getConnection();
      String queryL = "insert into USER_INFO_TBL VALUE(?,?,?);";
      PreparedStatement preparedStatementL = connectionL.prepareStatement(queryL);
      preparedStatementL.setString(1, email);
      preparedStatementL.setString(2, name);
      preparedStatementL.setString(3, password);
      preparedStatementL.executeUpdate();
      preparedStatementL.close();
      connectionL.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    }
  }
}
