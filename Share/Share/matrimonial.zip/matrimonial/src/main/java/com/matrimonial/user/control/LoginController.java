package com.matrimonial.user.control;

import com.matrimonial.user.dao.AdminDao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    processRequest(request, response);
  }

  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    processRequest(request, response);
  }

  /**
   * 
   * @param request
   * @param response
   * @throws ServletException
   * @throws IOException
   */
  private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String userIdL = request.getParameter("USER_ID");
    String passwordL = request.getParameter("USER_PASSWORD");
    AdminDao adminDaoL = new AdminDao();
    boolean isValidUserL = adminDaoL.isValidUser(userIdL, passwordL);
    HttpSession sessionL = request.getSession(false);
    response.setContentType("text/html");
    PrintWriter writerL = null;
    try {
      if (isValidUserL) {
        sessionL.setAttribute("IS_USER_LOGIN", "1");
        writerL = response.getWriter();
        writerL.print("true");
      } else {
        sessionL.setAttribute("IS_USER_LOGIN", "0");
        writerL = response.getWriter();
        writerL.print("false");
      }
    } catch (Exception exception) {
      exception.printStackTrace();
    } finally {
      if (writerL != null) {
        writerL.flush();
        writerL.close();
      }
    }
  }
}
