package com.matrimonial.user.control;

import com.matrimonial.user.dao.AdminDao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddUserController
 */
public class AddUserController extends HttpServlet {
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    processRequest(request, response);
  }

  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    processRequest(request, response);
  }

  /**
   * 
   * @param request
   * @param response
   * @throws ServletException
   * @throws IOException
   */
  private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String usernameL = request.getParameter("USER_NAME");
    String passwordL = request.getParameter("USER_PASSWORD");
    String emailL = request.getParameter("USER_EMAIL");
    AdminDao adminDaoL = new AdminDao();
    response.setContentType("text/html");
    PrintWriter writerL = null;
    try {
      if (adminDaoL.isUniqueEmail(emailL)) {
        adminDaoL.insertUser(emailL, usernameL, passwordL);
        writerL = response.getWriter();
        writerL.print("true");
      } else {
        writerL = response.getWriter();
        writerL.print("false");
      }
    } catch (Exception exception) {
      exception.printStackTrace();
    } finally {
      if (writerL != null) {
        writerL.flush();
        writerL.close();
      }
    }
  }

}
